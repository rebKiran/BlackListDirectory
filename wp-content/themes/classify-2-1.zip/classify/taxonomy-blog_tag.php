<?php
/**
 * The template for displaying archives of blog categories
 *
 * it uses the template for taxonomy-blog-general
 *
 * @package WordPress
 * @subpackage classify-child
 * @since classify 1.0
 */

get_template_part ( 'taxonomy', 'blog-general' );

 ?>
