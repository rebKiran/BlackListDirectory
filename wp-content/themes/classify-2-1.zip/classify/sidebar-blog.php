<?php if ( is_active_sidebar( 'sidebar-blog' ) ) : ?>
	<?php dynamic_sidebar('sidebar-blog'); ?>
<?php endif; ?>