<?php


/**
 * Template Name: Add Business
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */
/*if ( !is_user_logged_in() ) {
	wp_redirect( home_url() ); exit;
}elseif(!(isset($_GET['post']))) {
	wp_redirect( home_url() ); exit;
	}else{ 
}*/

get_header(); ?>

<?php 	

$wp_session = WP_Session::get_instance();
/*echo '<pre/>';
print_r($wp_session);
die( 'Here' );*/
$data = json_decode($wp_session->json_out() ); 
$product = $data->product;
$banner_id = $data->banner_id;
$price = $data->price;
$json = $data->json;
$data_uri = $data->data_uri;
$banner_url = $data->banner_url;

 $url = get_permalink( $product );
/*echo '<pre/>';
print_r($wp_session);*/
//$product = $wp_session->container;

$data = json_decode($wp_session->json_out() ); 

global $wpdb;

$flag = 1;				
if(isset($_POST['submitted'])) {
	/*echo '<pre/>';
	print_r($_POST);die;*/
	$flag = 2;
	if(trim($_POST['firstname']) === '') {
		$firstnameError = esc_html__( 'Please enter a Firstname.', 'classify' );
		$hasError = true;
	} else {
		$firstname = trim($_POST['firstname']);
	}

	if(trim($_POST['lastname']) === '') {
		$lastnameError = esc_html__( 'Please enter a Lastname.', 'classify' );
		$hasError = true;
	} else {
		$lastname = trim($_POST['lastname']);
	}
	
	if(trim($_POST['email_address']) === '') {
		$email_addressError = esc_html__( 'Please enter a Email Address.', 'classify' );
		$hasError = true;
	} else {
		$email_address = trim($_POST['email_address']);
	}
	if(trim($_POST['business_name']) === '') {
		$firstnameError = esc_html__( 'Please enter a Firstname.', 'classify' );
		$hasError = true;
	} else {
		$business_name = trim($_POST['business_name']);
	}

	if(trim($_POST['phone_number']) === '') {
		$lastnameError = esc_html__( 'Please enter a Phone Number.', 'classify' );
		$hasError = true;
	} else {
		$phone_number = trim($_POST['phone_number']);
	}
	

	$web_address = trim($_POST['web_address']);
	$business_purpose = $_POST['business_purpose'];
	$category_name = $_POST['category_name'];
	
	$owner    = $_POST['owner'];
	$business_role = $_POST['business_role'];
	$phone    = $_POST['contact']; //numeric value use: %d
	$state  	 = $_POST['state']; //string value use: %s
	$city   = $_POST['city']; //string value use: %s
	$mailing_address   = $_POST['mailing_address']; //string value use: %s
	$street_address   = $_POST['street_address']; //string value use: %s
	$address   = $_POST['address']; //string value use: %s
	$contact   = $_POST['contact']; //string value use: %s
	//$category_name = $_POST['category_name'];
	
	/*$product   = $_POST['contact']; //string value use: %s
	$banner_id   = $_POST['contact']; //string value use: %s
	$data_uri   = $_POST['contact']; //string value use: %s
	$price   = $_POST['contact']; //string value use: %s*/
	
	


	global $wpdb;
	
	 $sql = "INSERT INTO `wp_questionnaire` 
	   (`owner`, `business_role`, `firstname`, `lastname`, `mailing_address`, `street_address`, `address`, `city`, `state`, `zipcode`, `email`, `contact`, `product_id`, `banner_id`,  `price`,  `image`, `banner_url`,`business_name`, `web_address`, `category` , `business_phone_number`, `business_purpose` )
	   values ('Yes','$business_role','$firstname','$lastname', '$mailing_address', '$street_address', '$address',
			 '$city', '$state', '422105', '$email_address', '$contact', '$product','$banner_id', '$price','$data_uri','$banner_url', '$business_name', '$web_address', '$category_name' ,'$phone_number', '$business_purpose')";
  
	$wpdb->query($sql);
	?>
	<script type="text/javascript">
               window.location='<?php echo $url;?>';
     </script>
<?php 
} 

/*if(isset($_POST['submitted_cart'])) {
	
}*/
/*
if(isset($_POST['submitted_business'])) {

	if(trim($_POST['business_name']) === '') {
		$firstnameError = esc_html__( 'Please enter a Firstname.', 'classify' );
		$hasError = true;
	} else {
		$business_name = trim($_POST['business_name']);
	}

	if(trim($_POST['phone_number']) === '') {
		$lastnameError = esc_html__( 'Please enter a Phone Number.', 'classify' );
		$hasError = true;
	} else {
		$phone_number = trim($_POST['phone_number']);
	}
	

	$web_address = trim($_POST['web_address']);
	$business_purpose = $_POST['business_purpose'];
	$category_name = $_POST['category_name'];
	
		global $wpdb;
	
	
	$sql = "INSERT INTO `wp_about_business` (`name`, `web_address`, `phone_number`, `business_purpose`) VALUES ( '$business_name', '$web_address', '$$phone_number', '$$business_purpose ')";

	$wpdb->query($sql);
}*/
?>	
  
<section class="ads-main-page ">
<div class="container">
<?php if( 1 == $flag ){ ?>
<div >
	<ul class="tabs-nav">
    <!--<li class=""><a href="#tab-1" rel="nofollow"></a>
    </li>-->
   <!-- <li class="tab-active"><a href="#tab-2" rel="nofollow">About Your Business</a>
    </li>-->
</ul>
<div class="tabs-stage">
    <div id="tab-1" >
        <div id="upload-ad" >

					<form class="form-item" action="http://blacklistdir.rebelute.in/about-your-business/" id="primaryPostForm" method="POST" enctype="multipart/form-data">

							<h2 style="margin-left:10px">About You</h2>

							<input type="text" id="business_role" name="business_role" value="Yes" size="60" class="form-text required input-textarea half" placeholder="First">
							
							
							<div class="clearfix"></div>

							<label class="gfield_label gfield_label_before_complex" for="input_1_30_3" style="font-size: 20px !important;
    font-weight: bold !important;
    color: #1e73be !important;
    border-bottom: 1px solid;
    width: 96%;
margin:10px;
    padding-bottom: 8px;display:inline-block">Name<span class="gfield_required">*</span></label>
							<input type="text" id="firstname" name="firstname" style="margin-left:10px" value="" size="60" class="form-text required input-textarea half" placeholder="First">
						<input type="text" id="lastname" name="lastname" value="" size="60" class="form-text required input-textarea half" placeholder="Last">	
							
							
							<div class="clearfix"></div>
							<label class="gfield_label gfield_label_before_complex" for="input_1_30_3" style="font-size: 20px !important;
    font-weight: bold !important;
    color: #1e73be !important;
    border-bottom: 1px solid;
    width: 96%;
margin:10px;
    padding-bottom: 8px;display:inline-block">Mailing Address<span class="gfield_required">*</span></label>
							

<input style="margin-left:10px" type="text" id="mailing_address" name="mailing_address" value="" size="12" class="form-text required input-textarea half" placeholder="Mailing Address">	


<input type="text" id="street_address" name="street_address" value="" style="margin-left:10px"class="form-text required input-textarea half" placeholder="Street Address">
							
							
							
							<input  style="margin-left:10px" type="text" id="address" name="address" value="" class="form-text required input-textarea half" placeholder="Address Line 2">
							
							<br clear="all">
							<input type="text" style="margin-left:10px" id="state" name="state" value="" class="form-text required input-textarea half" placeholder="State">
							
							
							<input type="text" id="city" name="city" value="" class="form-text required input-textarea half" placeholder="City">
				
							
							<div class="clearfix"></div>

	<label class="gfield_label gfield_label_before_complex" for="input_1_30_3" style="font-size: 20px !important;
    font-weight: bold !important;
    color: #1e73be !important;
    border-bottom: 1px solid;
    width: 96%;
margin:10px;
    padding-bottom: 8px;display:inline-block">Email Address<span class="gfield_required">*</span></label>

	<input style="margin-left:10px" type="text" id="email_address" name="email_address" value="" class="form-text required input-textarea half" placeholder="Email Address">
							
							<br clear="all">
							

	<label class="gfield_label gfield_label_before_complex" for="input_1_30_3" style="font-size: 20px !important;
    font-weight: bold !important;
    color: #1e73be !important;
    border-bottom: 1px solid;
    width: 96%;
margin:10px;
    padding-bottom: 8px;display:inline-block">Contact Number<span class="gfield_required">*</span></label>
<input style="margin-left:10px" type="text" id="contact" name="contact" value="" class="form-text required input-textarea half" placeholder="Contact Number">
<br clear="all">
<h2 style="margin-left:10px">About Your Business</h2>
<br clear="all">
<label class="gfield_label gfield_label_before_complex" for="input_1_30_3" style="font-size: 20px !important;
    font-weight: bold !important;
    color: #1e73be !important;
    border-bottom: 1px solid;
    width: 96%;
margin:10px;
    padding-bottom: 8px;display:inline-block">Business Name<span class="gfield_required">*</span></label>
<input style="margin-left:10px" type="text" id="business_name" name="business_name" value="" size="60" class="form-text required input-textarea half" placeholder="Business Name">
							
<div class="clearfix"></div>
<label class="gfield_label gfield_label_before_complex" for="input_1_30_3" style="font-size: 20px !important;
    font-weight: bold !important;
    color: #1e73be !important;
    border-bottom: 1px solid;
    width: 96%;
margin:10px;
    padding-bottom: 8px;display:inline-block">Web Address<span class="gfield_required">*</span></label>
<input style="margin-left:10px" type="text" id="web_address" name="web_address" value="" size="60" class="form-text required input-textarea half" placeholder="Web Address">
<div class="clearfix"></div>

<label class="gfield_label gfield_label_before_complex" for="input_1_30_3" style="font-size: 20px !important;
    font-weight: bold !important;
    color: #1e73be !important;
    border-bottom: 1px solid;
    width: 96%;
margin:10px;
    padding-bottom: 8px;display:inline-block">Phone Number<span class="gfield_required">*</span></label>

		
							
							<input style="margin-left:10px" type="text" id="phone_number" name="phone_number" value="" size="60" class="form-text required input-textarea half" placeholder="Phone Number"><div class="clearfix"></div>

				<label class="gfield_label gfield_label_before_complex" for="input_1_30_3" style="font-size: 20px !important;
    font-weight: bold !important;
    color: #1e73be !important;
    border-bottom: 1px solid;
    width: 96%;
margin:10px;
    padding-bottom: 8px;display:inline-block">Business Type<span class="gfield_required">*</span></label>			
							
							<div style="margin-left:10px" id="edit-field-category-wrapper" class="views-exposed-widget views-widget-filter-field_category">
						    <div class="views-widget">
						        <div class="control-group form-type-select form-item-field-category form-item">
									<div class="controls"> 
										<select id="edit-field-category" name="category_name" class="form-select" style="display: none;">
													
											<option value="All" selected="selected"><?php echo $trns_category; ?>...</option>
											<?php
											$args = array(
												'hierarchical' => '0',
												'hide_empty' => '0'
											);
											$categories = get_categories($args);
										/*	print_r($categories);
											die('Here');*/
												foreach ($categories as $cat) {
													if ($cat->category_parent == 0) { 
														$catID = $cat->cat_ID;
													?>
														<option value="<?php echo $catID; ?>"><?php echo $cat->cat_name; ?></option>
																			
												<?php 
													$args2 = array(
														'hide_empty' => '0',
														'parent' => $catID
													);
													$categories = get_categories($args2);
													foreach ($categories as $cat) { ?>
														<option value="<?php echo  $cat->cat_ID; ?>">- <?php echo $cat->cat_name; ?></option>
												<?php } ?>

												<?php } else { ?>
												<?php }
											} ?>

										</select>
									</div>
								</div>
						    </div>
						</div>
					    <br clear="all">
						
							
							<br clear="all">
						
						<br clear="all">	
							

						<div class="publish-ad-button">
							
							<input type="hidden" name="submitted" id="submitted" value="true" />
							<button class="btn form-submit" id="edit-submit" name="op" value="Publish Ad" type="submit" style="width:20%;"><?php _e('Lets Get Listed', 'classify') ?></button>
						</div>

					</form>

	    		</div>
    </div>
   <!-- <div id="tab-2" style="display: block;">
         <div id="upload-ad" >

					<form class="form-item" action="http://localhost/blacklistdir/about-your-business/" id="primaryPostForm" method="POST" enctype="multipart/form-data">

						<h2></h2>

						
						
						<br clear="all">
						
						
						
						<br clear="all">
						
						
						

							
						<br clear="all">
						<fieldset class="input-title">
							<textarea name="business_purpose" id="video" cols="15" rows="5" placeholder="Briefly describe the purpose of the business" ></textarea>
							<p class="help-block"></p>
						</fieldset>	
							
						<div class="publish-ad-button">
							<input type="hidden" name="hid_banner_id" id="hid_banner_id" value="<?php echo $banner_id;?>" />
							<input type="hidden" name="submitted_business" id="submitted_business" value="true" />
							<button class="btn form-submit" id="edit-submit" name="op" value="Lets Get Listed" type="submit"><?php _e('Lets Get Listed', 'classify') ?></button>
						</div>

					</form>

	    		</div>
    </div>-->
</div>
</div>
<?php } else { 

//$banner_id = $_POST['hid_banner_id'];
?>

<form action="http://localhost/blacklistdir/cart/" method="post">

		<input name="add-to-cart" type="hidden" value="<?php echo $banner_id; ?>" />

		<input name="quantity" type="number" value="1" min="1"  />

		<input name="submit" type="submit" value="Add to cart" />

	</form>

	
<?php } ?>
</div>
</section>

<script type="text/javascript">//<![CDATA[
jQuery.noConflict();
jQuery( document ).ready(function( $ ) {
	 $('.tabs-nav li a').on('click', function (event) { 
		event.preventDefault();
		
	    $('.tab-active').removeClass('tab-active');
		$(this).parent().addClass('tab-active');
		//$('.tabs-stage div').hide();
		//alert( $(this).attr('href'));
		if( '#tab-1' == $(this).attr('href')) {
			$('#tab-1').show();
			$('#tab-2').hide();
		} else {
			$('#tab-2').show();
			$('#tab-1').hide();
		 }	
		//alert( $(this).parent(). );
		///alert( $(this).attr('href') );
		//$( $(this).attr('href')).show();
		//$($(this).attr('href')).show();
	});
	$('.tabs-nav a:first').trigger('click'); // Default
});
// C
/*$(function(){
// From http://learn.shayhowe.com/advanced-html-css/jquery

// Change tab class and display content


	$('.tabs-nav a:first').trigger('click'); // Default
});//]]> 
*/

</script>
  
<style>

.step-tab {
	padding: 39px 30px;
}

ul, li, div {
    background: hsla(0, 0%, 0%, 0);
    border: 0;
    font-size: 100%;
    margin: 0;
    outline: 0;
    padding: 0;
    vertical-align: baseline;
    font: 13px/20px "Droid Sans", Arial, "Helvetica Neue", "Lucida Grande", sans-serif;
    text-shadow: 0 1px 0 hsl(0, 100%, 100%);
}
li {
    display: list-item;
    text-align: -webkit-match-parent;
}
.tabs-nav {
    list-style: none;
    margin: 0;
    padding: 0;
}
.tabs-nav li:first-child a {
    border-right: 0;
    -moz-border-radius-topleft: 6px;
    -webkit-border-top-left-radius: 6px;
    border-top-left-radius: 6px;
}
.tabs-nav .tab-active a {
    background: hsl(0, 100%, 100%);
    border-bottom-color: hsla(0, 0%, 0%, 0);
    color: hsl(85, 54%, 51%);
    cursor: default;
}
.tabs-nav a {
    background: hsl(120, 11%, 96%);
    border: 1px solid hsl(210, 6%, 79%);
    color: hsl(215, 6%, 57%);
    display: block;
    font-size: 11px;
    font-weight: bold;
    height: 40px;
    line-height: 44px;
    text-align: center;
    text-transform: uppercase;
    width: 140px;
}
.tabs-nav li {
    float: left;
}
.tabs-stage {
    border: 1px solid hsl(210, 6%, 79%);
    -webkit-border-radius: 0 0 6px 6px;
    -moz-border-radius: 0 0 6px 6px;
    -ms-border-radius: 0 0 6px 6px;
    -o-border-radius: 0 0 6px 6px;
    border-radius: 0 0 6px 6px;

    clear: both;
    margin-bottom: 20px;
    position: relative;
    top: -1px;
    width: 100%;
}
.tabs-stage p {
    margin: 0;
    padding: 20px;
    color: hsl(0, 0%, 33%);
}
</style>
<?php get_footer(); ?>
