<html style="background:#444"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">		
		<title><?php wp_title( '|', true, 'right' ); ?></title>
	</head>
	<body>
		<div id="email_container">
			<div style="width:100%; margin:50px auto 12px auto" id="email_header">
				<span style="background:#fff; color:#fff; padding:12px;font-family:trebuchet ms; letter-spacing:1px; 
					-moz-border-radius-topleft:5px; -webkit-border-top-left-radius:5px; 
					border-top-left-radius:5px;moz-border-radius-topright:5px; -webkit-border-top-right-radius:5px; 
					border-top-right-radius:5px;">
					 <?php get_site_url(); ?>
				</span></div>
			</div>		
		
			<div style="width:99%; background:#fff; margin:0 auto; border:1px solid #e6e6e6;
				moz-border-radius:5px; -webkit-border-radus:5px; border-radius:5px; color:#454545;line-height:1.5em; " id="email_content">				
				