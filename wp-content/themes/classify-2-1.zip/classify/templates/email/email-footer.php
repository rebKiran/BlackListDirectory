				<p style="font-size:15px; font-family:Open Sans; padding:0 15px;">
					<?php esc_html_e( 'Regards', 'classify' ); ?>,<br>
					<?php echo  $blog_title = get_bloginfo('name'); ?>
				</p>
				
				<div style="text-align:center; padding:20px 0; color:#fff; background:#444;" id="email_footer"> 
					<small style="font-size:15px; color:#fff; line-height:15px; font-family:Open Sans;">
						<?php esc_html_e( 'You have received this email because you are a member of', 'classify' ); ?> <strong><?php echo  $blog_title = get_bloginfo('name'); ?>	</strong>					
					</small>
				</div>
				
			</div>
		
	
</body></html>