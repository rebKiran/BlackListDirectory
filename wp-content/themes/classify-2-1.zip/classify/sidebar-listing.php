<?php if ( !function_exists('dynamic_sidebar')
    || !dynamic_sidebar('listing') ) : ?>
	
<?php endif; ?>